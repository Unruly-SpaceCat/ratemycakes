var Cake = require('../models/cake');

// Export functions for our routes.js file to use. This is where the logic of
// your server will go.
module.exports = {

    home_function: function(req, res){
        console.log("get all")
        cakes = Cake.find().sort({createdAt: -1})
        .then(cakes=>  {
            var response = {}
            response['message'] = "Success"
            response['cakes'] = cakes
            res.json(response)
        })
        .catch(err => res.json(err))
    },
    get_one: function(req, res){
        const { id } = req.params
        Cake.findOne({_id: id })
        .then(cake => res.json(cake))
        .catch(err => res.json(err))
    },
    create_one: function(req, res){
        console.log(req.body)
        const newcake = new Cake()
        newcake.title = req.body.title
        newcake.baker = req.body.baker
        newcake.photo = req.body.photo
        newcake.save()
        .then(newCake => {
            console.log("new cake saved", newCake)
            res.json(newCake)
        })
        .catch(err => {
            console.log(err)
            res.json(err)
        })
    },
    update_one: function(req, res){
        const { id } = req.params
        console.log(id)
        console.log(req.body)
        Cake.findOne({_id: id })
        .then(cake => {
            console.log(cake)
            rate = {"comment": req.body.comment, "stars": req.body.stars}
            cake.ratings.push(rate)
            cake.save() 
            console.log(cake)
        })
        .catch(err => res.json(err))
        .then(updatedcake => {
            console.log("updated cake", updatedcake)
            var response = {}
            response['message'] = "Success"
            response['cake'] - updatedcake
            res.json(response)
        })
    },
    //delete_one: function(req, res){
    //    const { id } = req.params       
    //    Cake.deleteOne({_id: id })
    //    .then(deletedtask => {
    //        console.log(deletedtask)
    //        var response = {}
    //        response['message'] = "Success"
    //        res.json(response)
    //    })
    //     .catch(err => {
    //         console.log(err)
    //         res.redirect('/tasks')
    //    })
    //}
}