var mongoose = require('mongoose');

var CakeSchema = new mongoose.Schema({
  title: {
    type: String,
    required: [
        true,
        "This field cannot be blank"
    ]
},
  baker: {
    type: String,
    required: [
        true,
        "This field cannot be blank"
    ]
},
photo: {
    type: String,
    required: [
        true,
        "This field cannot be blank"
    ]
},
  ratings: [
      { comment: 
        {type: String, default: ""}, 
        stars: 
        {type: Number, default: null}
    }],
},     
{timestamps: true });

var Cake = mongoose.model('Cake', CakeSchema);
module.exports = Cake;