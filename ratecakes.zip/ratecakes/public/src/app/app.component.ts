import { Component, OnInit } from '@angular/core';
import { HttpService } from './http.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'public';
  cakesloaded: boolean
  cakes: any;
  newcake: any;
  stars: number;
  comment: string;
  rating: any;
  selectedCake: any;
  selectedCakeAverage: any;
  constructor(private _httpService: HttpService){}

  ngOnInit(){
    this.cakes = []
    this.cakesloaded = false
    this.rating = {}
    this.newcake = { title: "", baker: "", photo: ""}
    this.stars = null
    this.comment = ""
    this.getcakes()
  }
  getcakes(){
    let observable = this._httpService.getcakes();
    observable.subscribe(data => {
      this.cakes = data['cakes']
      this.cakesloaded = true
      console.log(this.cakes)
    })
  }
  makeNewCake(){
    let observable = this._httpService.sendNewCake(this.newcake)
    observable.subscribe()
    this.newcake = { title: "", baker: "", photo: ""}
    this.getcakes()
  }
  addStars(value){
    this.stars = value
  }
  addComment(value){
    this.comment = value
  }
  sendRating(id){
    this.rating['comment'] = this.comment
    this.rating['stars'] = this.stars
    let observable = this._httpService.addNewRating(id, this.rating)
    observable.subscribe()
    this.getcakes()
  }

  cakeToShow(cake){
    this.selectedCake = cake
    let sum = 0
    let counter = 0
    for(var i in this.selectedCake.ratings){
      if(this.selectedCake.ratings[i].stars != null){
      sum+=this.selectedCake.ratings[i].stars
      counter++
      }
    }
    this.selectedCakeAverage = sum/counter
  }

}
