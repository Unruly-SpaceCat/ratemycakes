var controller = require('../controllers/controller');

module.exports = function(app) {
    app.get('/cakes', controller.home_function);
    app.get('/cakes/:id', controller.get_one);
    app.post('/cakes', controller.create_one);
    app.put('/cakes/:id', controller.update_one);
}